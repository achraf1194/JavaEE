package tn.esprit.PiPub.services;

import javax.ejb.Remote;

@Remote
public interface TodoServiceRemote {

}
